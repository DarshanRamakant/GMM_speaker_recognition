clc;
clear all;
load model;
files_test = getAllFiles('C:\Users\darshan\Documents\MATLAB\spk_rec_data_with_division\test');
for k = 1:length(files_test)
speech_sig = wavread(files_test{k});
c = melcepst(speech_sig,11025,'E0dD');
[m n]=size(c);
score_matrix =[];
for i = 1:22
    obj = gmdistribution(M{i},V{i},W{i});
    y = pdf(obj,c);
    score_matrix = [score_matrix,y];
    %[l(i) r1 r2 r3]=gaussmixp(c(j,:),M{i},V{i},W{i});
end
[max_val labels]=max(score_matrix,[],2);
predict_test(k) = mode(labels);
k
end
expected_test =[];
for i =1:22
    expected_test = [expected_test,i*ones(1,2)];
end
test_accuracy =100*( sum(predict_test == expected_test) / length(predict_test==expected_test))