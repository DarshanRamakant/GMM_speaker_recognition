clc;
clear all;
[M V W]=train_GMM('..\lang_rec_data_with_division\train',4,16);
save('model_lang','M','V','W');
files = getAllFiles('..\lang_rec_data_with_division\train');
h_train = waitbar(0,'Init..');
for k = 1:length(files)
speech_sig = wavread(files{k});
c = melcepst(speech_sig,11025,'E0dD');
score_matrix =[];
for i = 1:4
    obj = gmdistribution(M{i},V{i},W{i});
    y = pdf(obj,c);
    score_matrix = [score_matrix,y];
end
[max_val labels]=max(score_matrix,[],2);
predict(k) = mode(labels);
waitbar(k/length(files),h_train,'Training accuracy calculation...');
end
expected =[];
for i =1:4
    expected = [expected,i*ones(1,16)];
end
train_accuracy =100*( sum(predict == expected) / length(predict==expected))
close(h_train);


%testing phase
files_test = getAllFiles('..\lang_rec_data_with_division\test');
h_test = waitbar(0,'Init...');
for k = 1:length(files_test)
speech_sig = wavread(files_test{k});
c = melcepst(speech_sig,11025,'E0dD');
sm_test=[];
for i = 1:4
    obj = gmdistribution(M{i},V{i},W{i});
    y = pdf(obj,c);
    sm_test=[sm_test,y];
end
[val labels_test]= max(sm_test,[],2);
predict_test(k) =  mode(labels_test);
waitbar(k/length(files_test),h_test,'Testing accuracy calculation...');
end
expected_test =[];
for i =1:4
    expected_test = [expected_test,i*ones(1,4)];
end
test_accuracy =100*( sum(predict_test == expected_test) / length(predict_test==expected_test))
close(h_test);